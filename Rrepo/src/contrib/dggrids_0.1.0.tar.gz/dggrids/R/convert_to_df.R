#' @title Convert DGGRID gen. file to data frame
#'
#' @description Convert discrete global grid (DGGRID) .gen file to data frame.
#' @param filename name of DGGRID output file of type .gen
#' @param res resolution of the DGGRID (this number is attached to the resulting data frame)
#'
#' @details DGGRID produces .gen files with three columns, \code{id}, \code{lon} and \code{lat}. Polygons each have a unique identifier and following each polygon there is a line "END" that needs to be filtered out. This function takes the .gen file and converts it into a data frame with fields \code{lon, lat, id} and \code{res}.
#'
#' @export
dggrid_gen_to_df <- function(filename,res) {
    lat <- lon <- isna <- NULL # Suppress bindings warning

    if(!is.character(filename)) stop("filename needs to of type 'character'")
    if(!is.numeric(res)) stop("res needs to be of type character")
    X <- read.table(filename,
                    sep=" ",fill=T,
                    header=F,
                    col.names = c("id","lon","lat")) %>%
        filter(!(id == "END")) %>%  ## Sometimes DGGRID doesn't put in first space, this mutate caters for this
        mutate(isna = is.na(lat),
               lat = ifelse(isna,lon,lat),
               lon = ifelse(isna,as.numeric(as.character(X$id)),lon))
    X$id[X$isna] <- NA
    X <- select(X,-isna) %>%
        mutate(res = res,
               id = as.numeric(as.character(id)),
               centroid = as.numeric(!is.na(id))) %>%
        transform(id = spacetime::na.locf(id))
}
